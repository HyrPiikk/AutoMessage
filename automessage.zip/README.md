[![Discord](https://img.shields.io/discord/1194599544420319262.svg?label=&logo=discord&logoColor=ffffff&color=7389D8&labelColor=6A7EC2)](https://discord.gg/mnrDRA9Vgk)

# AutoMessage
Permet de répéter un message ou plusieur message !

# TODO List
- Configuration des messages et du temps
- dans le fichier config.yml

# Commands

| Commands | Description | Permission |
|----------|-------------|------------|
| no       | no          | no         |
